## ANCOMBCviz
ANCOMBCviz is a Python package for analyzing differential abundance of group by microbiome composition and visualizing the resulting ANCOM-BC as a plot.

## Method
In ANCOM-BC, program of analysis to diffrential abundance. This tool use compositional  microbiome relative abundance data analysis. and This method also use ANCOM-BC, LefSe2, ALDEx2 usually.
In ANCOMBCviz, this ANCOM-BC results file make image file. plot type is `barplot`, `heatmap`.
This package also need `numpy >= 2.0`, `pandas`, `matplotlib >= 0.7.1`, `seaborn`, `skbio.stats.composition.ancom`.



